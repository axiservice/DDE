//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by JavaDDE.rc
//
#define IDS_ERROR_UNKNOWN               7000
#define IDS_ERROR_CANNOT_CREATE_OBJECT_REFERENCE 7001
#define IDS_ERROR_CLIENT_IS_NOT_CONNECTED 7002
#define IDS_ERROR_CANNOT_CREATE_THREAD  7003
#define IDS_ERROR_INITIALIZATION_FAILED 7004
#define IDS_ERROR_CANNOT_CONNECT_TO_DDE_SERVICE 7005
#define IDS_ERROR_REQUEST_FAILED        7006
#define IDS_ERROR_ADVICE_FAILED         7007
#define IDS_ERROR_EXECUTE_FAILED        7008
#define IDS_ERROR_POKE_FAILED           7009
#define IDS_ERROR_SERVER_IS_NOT_STARTED 7010
#define IDS_ERROR_NAME_SERVICE          7011
#define IDS_ERROR_POSTADVISE            7012
#define IDS_STRING16384                 16384
#define IDS_STRING16385                 16385
#define IDS_STRING16386                 16386
#define IDS_STRING16387                 16387
#define IDS_STRING16388                 16388
#define IDS_STRING16389                 16389
#define IDS_STRING16390                 16390
#define IDS_STRING16391                 16391
#define IDS_STRING16392                 16392
#define IDS_STRING16393                 16393
#define IDS_STRING16394                 16394
#define IDS_STRING16395                 16395
#define IDS_STRING16396                 16396
#define IDS_STRING16397                 16397
#define IDS_STRING16398                 16398
#define IDS_STRING16399                 16399
#define IDS_STRING16400                 16400
#define IDS_STRING16401                 16401

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
